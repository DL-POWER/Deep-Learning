# Artificial_intelligence
This repo will contain all the material which i need to implement the artificial intelligence concepts
